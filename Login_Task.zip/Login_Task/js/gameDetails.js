function drawTable(obj){
    //adding welcome text with username from server
    welcomeText = game.add.text(0, 0, 'Welcome, ' + obj.name, {
        font: '18px Arial'
    });
    welcomeText.anchor.set(0.5);
    welcomeText.alignIn(background,Phaser.RIGHT,-300,-150);

    //adding balance info text from server
    balanceInfo = game.add.text(0, 0, 'Balance : ' + obj.balance, {
        font: '18px Arial'
    });
    balanceInfo.alignIn(welcomeText,Phaser.BOTTOM,0,-20);

    //getting game details in array
    var gameDetail = new Array();
    gameDetail = obj.game_details;
    console.log("gameDetailLength : "+gameDetail.length);

    //storing different data in different array
    var game_names = new Array();
    var types = new Array();
    var buyIns = new Array();
    var players = new Array();
    for(let i = 0; i < gameDetail.length; i++){
        game_names[i] = gameDetail[i].game_name;
        types[i] = gameDetail[i].type;
        buyIns[i] = gameDetail[i].buy_in;
        players[i] = gameDetail[i].players;
    }

    // creating table - and collection data from server and displaying in each cell
    let nameTitleBg = game.add.sprite(0,0,'box_title');
    nameTitleBg.alignIn(background,Phaser.LEFT,-170,-220);
    gameName = game.add.text(0, 0, ' Game Name ', {
        font: '18px Arial',
        fontStyle : 'bold',
        fill : '#fff'
    });

    gameName.alignIn(nameTitleBg,Phaser.CENTER);

    var gameNames = new Array();
    var nameBg = new Array();
    for(let i = 0; i < game_names.length; i++){
        if(i == 0){
            nameBg[i] = game.add.sprite(0,0,'box');
            gameNames[i] = game.add.text(0, 0, game_names[i], {
                font: '18px Arial'
            });

            nameBg[i].alignIn(nameTitleBg,Phaser.BOTTOM,0,-30);
            gameNames[i].alignIn(nameBg[i],Phaser.CENTER);

        }else{
            nameBg[i] = game.add.sprite(0,0,'box');
            gameNames[i] = game.add.text(0, 0, game_names[i], {
                font: '18px Arial'
            });

            nameBg[i].alignIn(nameBg[i-1],Phaser.BOTTOM,0,-25);
            gameNames[i].alignIn(nameBg[i],Phaser.CENTER);

        }
    }


    let typeTitleBg = game.add.sprite(0,0,'box_title');
    typeTitleBg.alignIn(nameTitleBg,Phaser.RIGHT,115,0);
    gameType = game.add.text(0, 0, ' Type ', {
        font: '18px Arial',
        fontStyle : 'bold',
        fill : '#fff'
    });
    // gameType.anchor.set(0.5);
    gameType.alignIn(typeTitleBg,Phaser.CENTER);

    var gameTypes = new Array();
    var typeBg = new Array();
    for(let i = 0; i < types.length; i++){
        if(i == 0){
            typeBg[i] = game.add.sprite(0,0,'box');
            gameTypes[i] = game.add.text(0, 0, types[i], {
                font: '18px Arial'
            });
            // gameTypes[i].anchor.set(0.5);
            typeBg[i].alignIn(typeTitleBg,Phaser.BOTTOM,0,-30);
            gameTypes[i].alignIn(typeBg[i],Phaser.CENTER);

        }else{
            typeBg[i] = game.add.sprite(0,0,'box');
            gameTypes[i] = game.add.text(0, 0, types[i], {
                font: '18px Arial'
            });
            // gameTypes[i].anchor.set(0.5);
            typeBg[i].alignIn(typeBg[i-1],Phaser.BOTTOM,0,-25);
            gameTypes[i].alignIn(typeBg[i],Phaser.CENTER);
        }
    }

    let buyInTitleBg = game.add.sprite(0,0,'box_title');
    buyInTitleBg.alignIn(typeTitleBg,Phaser.RIGHT,100,0);
    gameBuyIn = game.add.text(0, 0, ' Buy-In ', {
        font: '18px Arial',
        fontStyle : 'bold',
        fill : '#fff'
    });
    // gameType.anchor.set(0.5);
    gameBuyIn.alignIn(buyInTitleBg,Phaser.CENTER);

    var gameBuyIns = new Array();
    var buyInBg = new Array();
    for(let i = 0; i < buyIns.length; i++){
        if(i == 0){
            buyInBg[i] = game.add.sprite(0,0,'box');
            gameBuyIns[i] = game.add.text(0, 0, buyIns[i], {
                font: '18px Arial'
            });
            // gameTypes[i].anchor.set(0.5);
            buyInBg[i].alignIn(buyInTitleBg,Phaser.BOTTOM,0,-30);
            gameBuyIns[i].alignIn(buyInBg[i],Phaser.CENTER);

        }else{
            buyInBg[i] = game.add.sprite(0,0,'box');
            gameBuyIns[i] = game.add.text(0, 0, buyIns[i], {
                font: '18px Arial'
            });
            // gameTypes[i].anchor.set(0.5);
            buyInBg[i].alignIn(buyInBg[i-1],Phaser.BOTTOM,0,-25);
            gameBuyIns[i].alignIn(buyInBg[i],Phaser.CENTER);

        }
    }

    let playersTitleBg = game.add.sprite(0,0,'box_title');
    playersTitleBg.alignIn(buyInTitleBg,Phaser.RIGHT,100,0);
    gamePlayer = game.add.text(0, 0, ' Players ', {
        font: '18px Arial',
        fontStyle : 'bold',
        fill : '#fff'
    });
    // gameType.anchor.set(0.5);
    gamePlayer.alignIn(playersTitleBg,Phaser.CENTER);

    var gamePlayers = new Array();
    var playersBg = new Array();
    for(let i = 0; i < players.length; i++){
        if(i == 0){
            playersBg[i] = game.add.sprite(0,0,'box');
            gamePlayers[i] = game.add.text(0, 0, players[i], {
                font: '18px Arial'
            });
            // gameTypes[i].anchor.set(0.5);
            playersBg[i].alignIn(playersTitleBg,Phaser.BOTTOM,0,-30);
            gamePlayers[i].alignIn(playersBg[i],Phaser.CENTER);
        }else{
            playersBg[i] = game.add.sprite(0,0,'box');
            gamePlayers[i] = game.add.text(0, 0, players[i], {
                font: '18px Arial'
            });

            // gameTypes[i].anchor.set(0.5);
            playersBg[i].alignIn(playersBg[i-1],Phaser.BOTTOM,0,-25);
            gamePlayers[i].alignIn(playersBg[i],Phaser.CENTER);

        }
    }
}