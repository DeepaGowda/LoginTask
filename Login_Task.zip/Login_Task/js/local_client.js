function sendData(name, rememberMe){
    let response;

    var url = "ws://127.0.0.1:3000/";

    var data = {
        "name": name,
        "remember_me": rememberMe
    };

    var w = new WebSocket(url);

    w.onopen = function(evt){
        // console.log(evt);
        w.send(JSON.stringify(data));


    };
    w.onmessage = function(e) {
        response = e.data;
        console.log("response : " + response);
        var obj = JSON.parse(response);

        drawTable(obj);

    };

}