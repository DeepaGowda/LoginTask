var Websocketserver = require('ws').Server;
var wss = new Websocketserver({
    port:3000
});

wss.on("connection",function(ws){
    console.log("connected");
    ws.on("message",function(message){
        var obj = JSON.parse(message);

        //static json format response
        var response = {
            "status_code" : 200,
            "name" : obj.name,
            "remember_me" : obj.remember_me,
            "balance" : 20000,
            "game_details" : [
                {
                    "game_name" : "game1",
                    "type" : "slot",
                    "buy_in" : 200,
                    "players" : 2,

                },
                {
                    "game_name" : "game2",
                    "type" : "spin",
                    "buy_in" : 400,
                    "players" : 6,

                },
                {
                    "game_name" : "game3",
                    "type" : "casino",
                    "buy_in" : 100,
                    "players" : 6,

                },
                {
                    "game_name" : "game4",
                    "type" : "table",
                    "buy_in" : 300,
                    "players" : 4,

                }
            ]
        };
        ws.send(JSON.stringify(response));

    });

});
