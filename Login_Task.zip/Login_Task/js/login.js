var game = new Phaser.Game(window.innerWidth - 50, window.innerHeight -40, Phaser.AUTO, '', {create: create, preload: preload}, true);
var figure;
var user;
var testHolder;
var password;
var rememberMe = false;
var forgoted = false;
let welcomeText,balanceInfo,background,gameName,gameType,gameBuyIn,gamePlayer;
Phaser.Device.whenReady(function () {
    game.plugins.add(PhaserInput.Plugin);
    game.plugins.add(PhaserNineSlice.Plugin);
});

function preload() {
    game.load.image('bg', 'assets/images/background_cards.png');
    game.load.nineSlice('input', 'assets/images/input_field.png', 15);
    game.load.nineSlice('btn', 'assets/images/login_btn.png', 20, 23, 27, 28);
    game.load.spritesheet('checkbox', 'assets/images/checkbox.png', 35, 32);
    game.load.image('alter_box','assets/images/message_box.png');
    game.load.image('box','assets/images/box.png');
    game.load.image('box_title','assets/images/box_title.png');
}

function create() {

    let messageBox =  game.add.group();

        if (!game.device.desktop) {
        game.scale.setGameSize(window.innerWidth, window.innerHeight);
    }
    //let's add a nice background
        background=game.add.image(game.width / 2, game.height/2, 'bg');
        background.width = game.width ;
        background.height = game.height ;
        background.anchor.set(0.5);

    //title here!
    var login = game.add.text(game.width / 2, 140, 'Login', {
        font: '30px Arial',
        fontStyle : 'bold',
        fill: '#000'
    });
    login.anchor.set(0.5);
    //Here's the input field for the user's name
    var userBg = game.add.nineSlice(game.width / 2 , 190, 'input', null, 250, 50);
    userBg.anchor.set(0.5);
    user = game.add.inputField(0 , 0, {
        font: '18px Arial',
        fill: '#FFFFFF',
        fillAlpha: 0,
        fontWeight: 'bold',
        width: 200,
        max: 20,
        padding: 8,
        borderWidth: 1,
        borderColor: '#000',
        borderRadius: 6,
        placeHolder: 'Username',
        zoom: true,
        background : 'assets/images/btn_clean.png'
    });
    user.alignIn(userBg,Phaser.CENTER);
    user.tabIndex =0;

    // user.anchor.set(0.5);
    // user.blockInput = false;

    //We'd need a password too
    var passBg = game.add.nineSlice(game.width / 2 , 250, 'input', null, 250, 50);
    passBg.anchor.set(0.5);
    password = game.add.inputField(0 , 0, {
        font: '18px Arial',
        fill: '#FFFFFF',
        fillAlpha: 0,
        fontWeight: 'bold',
        width: 200,
        padding: 8,
        borderWidth: 1,
        borderColor: '#000',
        borderRadius: 6,
        placeHolder: 'Password',
        type: PhaserInput.InputType.password,
        zoom: true
    });
    password.alignIn(passBg,Phaser.CENTER);
    password.tabIndex =1;
    // password.focusOutOnEnter = false;
    // testHolder = password;


    var rememberMeGroup = game.add.group();
    var remember = game.add.sprite(0, 0, 'checkbox');
    remember.inputEnabled = true;
    remember.input.useHandCursor = true;
    remember.animations.add("unchecked",[0],1,true);
    remember.animations.add("checked",[1],1,true);
    remember.events.onInputDown.add(function() {
        if (!rememberMe) {
        console.log("1"+rememberMe);
        rememberMe = true;
        remember.animations.play("checked");
        }else{

            console.log("2"+rememberMe);
            rememberMe = false;
            remember.animations.play("unchecked");
        }

    });

    var rememberText = game.add.text(0,0,'Remember Me',{
        font: '20px Arial',
        fontStyle : 'bold',
        fill: '#000',

    });
    rememberMeGroup.add(remember);
    rememberMeGroup.add(rememberText);
    rememberMeGroup.alignIn(passBg,Phaser.BOTTOM_CENTER,-20,50);
    // remember.alignIn(rememberMeGroup,Phaser.CENTER,0,50);
    rememberText.alignIn(remember,Phaser.LEFT_CENTER,-40,0);

    var submitBtn = game.add.nineSlice(game.width / 2, 370, 'btn', null, 200, 50);
    submitBtn.anchor.set(0.5);
    var submit = game.add.text(0, 0, 'Login', {
        font: '18px Arial',
        fontStyle :'bold'
    });
    submit.alignIn(submitBtn,Phaser.CENTER);
    submitBtn.inputEnabled = true;
    submitBtn.input.useHandCursor = true;

    var forgotText = game.add.text(game.width / 2,440,'Forgot Password',{
        font: '20px Verdana',
        fontStyle : 'bold',
        fill: '#ee2c0c',

    });
    forgotText.anchor.set(0.5);

    var forgotTextUnderline = game.add.text(game.width / 2,445,'____',{
        font: '20px Verdana',
        fontStyle : 'bold',
        fill: '#ee2c0c',

    });
    forgotTextUnderline.width = 200;
    forgotTextUnderline.anchor.set(0.5);

    submitBtn.events.onInputDown.add(function () {
        //validation for empty fields
        if(user.value == "" && password.value == "") {
            console.log("Please enter username and password");
            showMessage('Please enter username and password','OK',400,200);
        }else if(user.value == ""){
            showMessage('Please enter username','OK',400,200);
        }else if(password.value == ""){
            showMessage('Please enter password','OK',400,200);
        }
        else {
            // making invisible previous screen
            login.visible = false;
            user.visible = false;
            password.visible = false;
            passBg.visible = false;
            userBg.visible = false;
            submit.visible = false;
            submitBtn.visible = false;
            remember.visible = false;
            rememberText.visible = false;
            forgotText.visible = false;
            forgotTextUnderline.visible = false;
            console.log("Forgot : " + forgoted + "\n" + "Remember : " + rememberMe);

            //sending data to server
            sendData(user.value,rememberMe)

        }

    });


    PhaserInput.onKeyboardOpen.add(function () {
        console.error("keyboard open", PhaserInput.KeyboardOpen)
    });
    PhaserInput.onKeyboardClose.add(function () {
        console.error("keyboard close", PhaserInput.KeyboardOpen)
    });
}

//showing alter popup for empty fields
function showMessage(text,btnText, w , h )
{

    if(this.messageBox){
        this.messageBox.destroy();
    }

    var msgBox =  game.add.group();
    var background_msg = game.add.sprite(0,0,'alter_box');

    var message = game.add.text(0, 0, text,{
        font : '18px Arial',
        color : '#000',

    });
    var okBtn = game.add.sprite(0, 0, 'btn');
    var okText = game.add.text(0, 0, btnText,{
        font : '18px Arial',
        color : '#000',
});
    console.log("step3");
    msgBox.add(background_msg);
    msgBox.add(message);
    msgBox.add(okBtn);
    msgBox.add(okText);

    background_msg.width = w;
    background_msg.height = h;

    msgBox.x = game.width / 2 - msgBox.width/2;
    msgBox.y = game.height / 2 - msgBox.height/2;

    message.alignIn(background_msg,Phaser.TOP_CENTER,0,-50);
    okBtn.alignIn(background_msg,Phaser.TOP_CENTER,0,-90);
    okText.alignIn(okBtn,Phaser.CENTER);

    this.messageBox = msgBox;
    okBtn.inputEnabled = true;
    okBtn.input.useHandCursor = true;
    okBtn.events.onInputDown.add(function(){
        this.messageBox.destroy();
    });


}